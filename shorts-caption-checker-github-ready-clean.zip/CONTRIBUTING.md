# Contributing

Thanks for helping make captions easier to check.

1. Open an issue describing a real usability bug or feature request; check for duplicates.
2. Fork the repository, create a branch, and implement a focused fix.
3. Run: `PYTHONPATH=src python -m unittest discover -s tests -v`.
4. Open a pull request describing why the change is useful and which tests cover it.

Please respect others, avoid submitting unrelated automated changes, and do not post spam pull requests. The project maintainer must evaluate contributions on merit.
