"""Dependency-free SubRip (.srt) parsing and caption checks."""
from dataclasses import asdict, dataclass
import re
from typing import List

TIME_RE = re.compile(r"^(\d{2,}):(\d{2}):(\d{2})[,.](\d{3})$")
ARROW_RE = re.compile(r"^\s*(.+?)\s*-->\s*(.+?)\s*$")
TAG_RE = re.compile(r"<[^>]*>")


@dataclass(frozen=True)
class Cue:
    number: int
    start_ms: int
    end_ms: int
    text: str


@dataclass(frozen=True)
class Finding:
    severity: str
    cue: int
    code: str
    message: str

    def to_dict(self):
        return asdict(self)


def parse_time(value: str) -> int:
    match = TIME_RE.fullmatch(value.strip())
    if not match:
        raise ValueError(f"Invalid SRT timestamp: {value!r}")
    hours, minutes, seconds, milliseconds = map(int, match.groups())
    if minutes > 59 or seconds > 59:
        raise ValueError(f"Timestamp outside valid clock range: {value!r}")
    return ((hours * 60 + minutes) * 60 + seconds) * 1000 + milliseconds


def parse_srt(content: str) -> List[Cue]:
    content = content.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    if not content.strip():
        raise ValueError("Subtitle file is empty")
    cues = []
    for block in re.split(r"\n\s*\n", content.strip()):
        lines = block.splitlines()
        if not lines:
            continue
        if lines[0].strip().isdigit():
            number = int(lines[0].strip())
            lines = lines[1:]
        else:
            number = len(cues) + 1
        if not lines:
            raise ValueError(f"Cue {number} has no timestamp line")
        match = ARROW_RE.match(lines[0])
        if not match:
            raise ValueError(f"Cue {number} has an invalid timestamp line: {lines[0]!r}")
        start_ms = parse_time(match.group(1))
        end_ms = parse_time(match.group(2))
        if len(lines) < 2 or not any(line.strip() for line in lines[1:]):
            raise ValueError(f"Cue {number} has no caption text")
        cues.append(Cue(number, start_ms, end_ms, "\n".join(lines[1:])))
    return cues


def check_cues(cues: List[Cue], *, max_cps: float = 18.0,
               max_line_chars: int = 42, max_lines: int = 2) -> List[Finding]:
    findings = []
    prev = None
    for cue in cues:
        duration_ms = cue.end_ms - cue.start_ms
        if duration_ms <= 0:
            findings.append(Finding("error", cue.number, "INVALID_DURATION",
                                    "Caption end must be later than start"))
        if prev is not None and cue.start_ms < prev.end_ms:
            findings.append(Finding("error", cue.number, "OVERLAP",
                                    f"Overlaps previous cue {prev.number}"))
        if prev is not None and cue.start_ms < prev.start_ms:
            findings.append(Finding("error", cue.number, "OUT_OF_ORDER",
                                    f"Starts before previous cue {prev.number}"))
        plain_lines = [TAG_RE.sub("", line).strip() for line in cue.text.splitlines()]
        if len(plain_lines) > max_lines:
            findings.append(Finding("warning", cue.number, "TOO_MANY_LINES",
                                    f"{len(plain_lines)} lines (limit: {max_lines})"))
        for i, line in enumerate(plain_lines, 1):
            if len(line) > max_line_chars:
                findings.append(Finding("warning", cue.number, "LONG_LINE",
                                        f"Line {i}: {len(line)} chars (limit: {max_line_chars})"))
        text_chars = sum(len(line) for line in plain_lines)
        if duration_ms > 0 and text_chars / (duration_ms / 1000) > max_cps:
            cps = text_chars / (duration_ms / 1000)
            findings.append(Finding("warning", cue.number, "FAST_READING",
                                    f"{cps:.1f} characters/sec (limit: {max_cps:g})"))
        prev = cue
    return findings
