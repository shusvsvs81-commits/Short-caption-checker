"""Check SRT caption files for common timing and readability issues."""
__version__ = "0.1.0"
