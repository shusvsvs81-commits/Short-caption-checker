"""Command-line interface for Shorts Caption Checker."""
import argparse
import json
from pathlib import Path
import sys

from .core import check_cues, parse_srt


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Detect subtitle timing overlaps and readability issues in .srt files."
    )
    parser.add_argument("file", type=Path, help="Path to a UTF-8 .srt file")
    parser.add_argument("--max-cps", type=float, default=18.0,
                        help="Maximum characters/second (default: 18)")
    parser.add_argument("--max-line-chars", type=int, default=42,
                        help="Maximum characters per line (default: 42)")
    parser.add_argument("--max-lines", type=int, default=2,
                        help="Maximum lines per caption (default: 2)")
    parser.add_argument("--format", choices=["text", "json"], default="text",
                        help="Output format")
    parser.add_argument("--fail-on-warning", action="store_true",
                        help="Exit with code 1 for any warning")
    args = parser.parse_args(argv)
    if args.max_cps <= 0 or args.max_line_chars < 1 or args.max_lines < 1:
        parser.error("Thresholds must be positive")
    try:
        content = args.file.read_text(encoding="utf-8-sig")
        cues = parse_srt(content)
    except (OSError, UnicodeError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    findings = check_cues(cues, max_cps=args.max_cps,
                          max_line_chars=args.max_line_chars,
                          max_lines=args.max_lines)
    errors = sum(x.severity == "error" for x in findings)
    warnings = sum(x.severity == "warning" for x in findings)
    if args.format == "json":
        print(json.dumps({"file": str(args.file), "cues": len(cues),
                          "errors": errors, "warnings": warnings,
                          "findings": [f.to_dict() for f in findings]}, indent=2))
    else:
        print(f"{args.file}: {len(cues)} cues, {errors} errors, {warnings} warnings")
        for finding in findings:
            print(f"  [{finding.severity.upper()}] cue {finding.cue} "
                  f"{finding.code}: {finding.message}")
    return 1 if errors or (args.fail_on_warning and warnings) else 0


if __name__ == "__main__":
    sys.exit(main())
