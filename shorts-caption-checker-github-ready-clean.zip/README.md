# Shorts Caption Checker

A small, **free and open-source** Python command-line tool that checks `.srt` subtitles for common problems before publishing YouTube Shorts, Reels, or other videos.

## What it checks

- Invalid caption durations (end time at or before start time)
- Overlapping and out-of-order captions
- Reading speed (characters per second)
- Lines that are too long
- Too many lines in one caption
- Text or JSON reports for video workflows

These heuristics are starting points. Captions in different languages and for different audiences may need different thresholds. It does not replace human review.

## Quick start

Requires Python 3.9 or newer.

```bash
python -m pip install .
shorts-caption-checker examples/demo.srt
shorts-caption-checker examples/demo.srt --format json
shorts-caption-checker examples/demo.srt --max-cps 20 --max-line-chars 35 --fail-on-warning
```

Exit codes: `0` = no errors (warnings allowed by default), `1` = errors or configured warning failure, `2` = input error.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Contributions with reproducible tests and helpful documentation are welcome.

## Roadmap

- Optional WebVTT support
- Optional batch folder scanning
- Machine-readable CI summary
- Better Unicode-aware reading speed for multilingual captions

## License

MIT — see [LICENSE](LICENSE).

## Project status

Early version (v0.1.0). **No download counts, contributor counts, community adoption, or popularity are claimed.** Those metrics should only be reported after real adoption.
