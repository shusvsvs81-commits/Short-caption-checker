import unittest
from shorts_caption_checker.core import parse_srt, parse_time, check_cues


class ParseTests(unittest.TestCase):
    def test_parse_valid(self):
        cues = parse_srt("1\n00:00:00,000 --> 00:00:02,000\nHello world\n")
        self.assertEqual((cues[0].start_ms, cues[0].end_ms), (0, 2000))
        self.assertEqual(cues[0].text, "Hello world")

    def test_comma_or_period(self):
        self.assertEqual(parse_time("00:00:01.230"), 1230)

    def test_invalid_clock(self):
        with self.assertRaises(ValueError):
            parse_time("00:62:01,000")

    def test_missing_caption(self):
        with self.assertRaises(ValueError):
            parse_srt("1\n00:00:00,000 --> 00:00:02,000")

    def test_empty(self):
        with self.assertRaises(ValueError):
            parse_srt("")

    def test_overlap_and_readability(self):
        cues = parse_srt("1\n00:00:00,000 --> 00:00:02,000\nHi\n\n"
                         "2\n00:00:01,900 --> 00:00:02,100\nA rather long caption that should be flagged.\n")
        codes = {f.code for f in check_cues(cues)}
        self.assertTrue({"OVERLAP", "LONG_LINE", "FAST_READING"} <= codes)

    def test_wrong_duration(self):
        cues = parse_srt("1\n00:00:02,000 --> 00:00:01,000\nWrong\n")
        self.assertEqual(check_cues(cues)[0].code, "INVALID_DURATION")

    def test_valid_caption_has_no_warnings(self):
        cues = parse_srt("1\n00:00:00,000 --> 00:00:02,000\nHello there!\n")
        self.assertEqual(check_cues(cues), [])


if __name__ == "__main__":
    unittest.main()
